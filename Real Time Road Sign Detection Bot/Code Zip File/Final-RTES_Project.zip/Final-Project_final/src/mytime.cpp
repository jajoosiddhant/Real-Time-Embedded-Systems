

/**
 * @file mytime.cpp
 * @brief This file consists of all the function definitions related to getting time.
 * @author Siddhant Jajoo.
 * @date 05/02/2019
 * @copyright Copyright (C) 2019
 * 
 */


#include "../inc/mytime.h"



//void get_time
